# ddharmon — curated demo cohorts

These are the exact inputs behind the ddharmon demo run: ~200-field curated subsets of three public
biomedical cohorts — **All of Us**, **CLSA**, and **UK Biobank** — chosen to overlap on common health &
demographic domains (sex, age, smoking, blood pressure, …) so a cross-cohort harmonization has real
matches to find.

## Contents
- `aou.csv`, `clsa.csv`, `ukbb.csv` — the curated demo dictionaries (REDCap / codebook style)
- `build_demo_data.py` — how these subsets were curated from the full public example data
- `build_demos.py`     — runs the ddharmon pipeline over them to produce a harmonization run

## Run it yourself
1. Install the tool: `pip install ddharmon`  → https://github.com/Phenome-Health/ddharmon
2. Get a CDE catalog: the full NIH CDE table ships in the ddharmon repo under `data/examples/`
   (`all_cdes_flat.tsv`); point `DDHARMON_CDE_DIR` at that folder.
3. Run (needs an Anthropic API key for the LLM stages):
   ```
   ANTHROPIC_API_KEY=sk-... DDHARMON_CDE_DIR=/path/to/ddharmon/data/examples \
     python build_demos.py --mode batch --datasets aou clsa ukbb
   ```
   Use `--mode preview` for a free (no-LLM) clustering-only dry run.

## Full data + provenance
The full (unsubsetted) cohort example CSVs and the scripts that build them from each cohort's public
source live in the **ddharmon** repo under `data/examples/` (see `data/examples/README.md` for the
source-URL → script → CSV provenance table):
  https://github.com/Phenome-Health/ddharmon

This GUI and the demo build scripts live in the **ddharmon-ui** repo:
  https://github.com/Phenome-Health/ddharmon-ui
